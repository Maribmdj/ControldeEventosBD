/*
Fecha: 01 OCTUBRE 2018
Autor: Mariela Barrantes
Descripcion: INSERT TIPOPERSONA
*/

INSERTS_CATALOGO.INSERTAR_CATALOGO_TIPOPERSONA('ADMINISTRADOR');
INSERTS_CATALOGO.INSERTAR_CATALOGO_TIPOPERSONA('PARTICIPANTE');
INSERTS_CATALOGO.INSERTAR_CATALOGO_TIPOPERSONA('PATROCINADOR');


/*
TIPOPERSONA: Activo - Inactivo - Cancelado - Pendiente
tipoPersona: Administrador - Participante - Patrocinador
tipoParticipante: Estudiante - Externo(Empresas)
*/

