/*
Fecha: 30 SETIEMBRE 2018
Autor: Nakisha Dixon
Descripcion: INSERT TABLA CORREO
*/

INSERTS_TABLAS.INSERTAR_CORREO('iramirez@gmail.com', 1);
INSERTS_TABLAS.INSERTAR_CORREO('agamora@hotmail.com', 2);
INSERTS_TABLAS.INSERTAR_CORREO('slebron@gmail.com', 3);
INSERTS_TABLAS.INSERTAR_CORREO('hcarabaca@yahoo.es', 4);
INSERTS_TABLAS.INSERTAR_CORREO('glorojas@gmail.com', 5);
INSERTS_TABLAS.INSERTAR_CORREO('isantos@gmail.com', 6);
INSERTS_TABLAS.INSERTAR_CORREO('mauval@hotmail.com', 7);
INSERTS_TABLAS.INSERTAR_CORREO('abrts@hotmail.com', 8);
