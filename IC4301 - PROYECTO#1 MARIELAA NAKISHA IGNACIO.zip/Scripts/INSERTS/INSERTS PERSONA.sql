/*
Fecha: 30 SETIEMBRE 2018
Autor: Nakisha Dixon
Descripcion: INSERT TABLA PERSONA
*/

INSERTS_TABLAS.INSERTAR_PERSONA('Ivan', 'Ramirez','Lopez', '2017103353', null, '500 metros sur del Lagar', 18,15,1,1,1,2, TO_DATE('30/06/1990','DD/MM/YYYY'));
INSERTS_TABLAS.INSERTAR_PERSONA('Adriana', 'Gamora', 'Soto', '2016335675', null, 'De la Soda Castro, 500 norte', 65,15,1,1,1,2, TO_DATE('04/03/1987','DD/MM/YYYY'));
INSERTS_TABLAS.INSERTAR_PERSONA('Silvania', 'Lebron', 'Walters', '1176707345', null, 'Contiguo a pulperia la esquina', 18,15,1,2,2,3, TO_DATE('21/02/1987','DD/MM/YYYY'));
INSERTS_TABLAS.INSERTAR_PERSONA('Hector', 'Carabaca', 'Barrios', '7015034523', null, 'Frente a la Iglesia Catolica', 57,10,1,2,2,4, TO_DATE('11/04/1993','DD/MM/YYYY'));
INSERTS_TABLAS.INSERTAR_PERSONA('Gloria', 'Rojas' , 'Ecomo', '1145784356', null, 'Urbanizacion Maderos', 40,15,2,2,1,5, TO_DATE('18/04/2000','DD/MM/YYYY'));
INSERTS_TABLAS.INSERTAR_PERSONA('Ignacio', 'Santos', 'Cascante', '2014546576', null, 'Venia segunda loma', 40,14,2,2,1,4, TO_DATE('10/05/1980','DD/MM/YYYY'));
INSERTS_TABLAS.INSERTAR_PERSONA('Mauricio', 'Valenciaga', 'Gabbana', '5067869806', null, 'Frente a Restaurant Verano', 22,15,2,3,2,11, TO_DATE('07/02/2000','DD/MM/YYYY'));
INSERTS_TABLAS.INSERTAR_PERSONA('Adrian', 'Barrantes', 'Alvarado', '2018104567', null, 'Barrio Indigena rancho 3', 18,15,4,3,2,12, TO_DATE('12/01/1991','DD/MM/YYYY'));
INSERTS_TABLAS.INSERTAR_PERSONA('MARIA', 'MATA','OBANDO', '601660591', null, '500 metros sur del Lagar', 18,15,1,2,1,2, TO_DATE('10/05/1962','DD/MM/YYYY'));
INSERTS_TABLAS.INSERTAR_PERSONA('YENIFER', 'BARRANTES', 'MATA', '11730055', null, 'De la Soda Castro, 500 norte', 65,15,1,2,1,2, TO_DATE('11/04/1990','DD/MM/YYYY'));
INSERTS_TABLAS.INSERTAR_PERSONA('CHRISTIAN', 'BARRANTES', 'MATA', '116320498', null, 'Contiguo a pulperia la esquina', 18,15,1,2,1,3, TO_DATE('07/02/1996','DD/MM/YYYY'));
INSERTS_TABLAS.INSERTAR_PERSONA('DYLAN', 'VILLEGAS', 'BARRANTES', '121730432', null, 'Frente a la Iglesia Catolica', 57,15,1,2,1,4, TO_DATE('18/04/2007','DD/MM/YYYY'));
INSERTS_TABLAS.INSERTAR_PERSONA('MARISOL', 'CAMPOS' , 'ARIAS', '301330753', null, 'Urbanizacion Maderos', 40,15,1,2,1,5, TO_DATE('27/04/1970','DD/MM/YYYY'));
INSERTS_TABLAS.INSERTAR_PERSONA('JAZMIN', 'OBANDO', 'CAMPOS', '116320749', null, 'Venia segunda loma', 40,10,1,2,1,4, TO_DATE('11/04/1996','DD/MM/YYYY'));
INSERTS_TABLAS.INSERTAR_PERSONA('VICTORIA', 'OBANDO', 'CAMPOS', '702320987', null, 'Frente a Restaurant Verano', 22,15,1,2,1,11, TO_DATE('12/01/2006','DD/MM/YYYY'));
INSERTS_TABLAS.INSERTAR_PERSONA('VIVIANA', 'MORA', 'ARAYA', '115327412', null, 'Barrio Indigena rancho 3', 18,15,1,2,1,12, TO_DATE('28/09/1993','DD/MM/YYYY'));
