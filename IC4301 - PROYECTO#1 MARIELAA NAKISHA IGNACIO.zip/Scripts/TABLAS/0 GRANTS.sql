-- GRANTS DESDE SYSTEM

--CONECTARSE A CE
GRANT connect to ce;
GRANT create table to ce;

