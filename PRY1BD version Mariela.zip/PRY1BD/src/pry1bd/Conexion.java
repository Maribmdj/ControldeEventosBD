package pry1bd;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.*;
import oracle.jdbc.OracleTypes;

/**
 * Autora: Mariela Barrantes
 *Descripcion: Esta clase se encarga de toda la conexion con la base de datos
 */

public class Conexion {
    
    //Variables de conexion
    private Connection conexion;
    static Statement s;
    static ResultSet rs;
    CallableStatement cs = null;
    String sql = null;
    
    public Connection db;
    
    public Connection getConexion() {
        return conexion;
    }    
    
    public void setConexion(Connection conexion)  {
        this.conexion = conexion;
    }
    public void Conectar()
    {
        try{
            String usuario = "CE";
            String contrasena = "CE";
            Class.forName("oracle.jdbc.OracleDriver");
            String cadenaConexion = "jdbc:oracle:thin:@localhost:1521:dbprueba";
            setConexion(DriverManager.getConnection(cadenaConexion, usuario, contrasena));
            if (getConexion() != null){
                System.out.println("Se ha establecido la conexion");  
            }
            else { System.out.println("Error de conexion");  }
        }catch(Exception e)
        {   e.printStackTrace();    }
        }

    
    /*Autor: Mariela Barrantes
    Descripcion: conaulta para mostrar los administradores*/
    public ResultSet consultaAdmins(String nombre, String apellido, String identf, String usuario)  {
        db = getConexion();
        sql = "{call ce.getAdministrador(?,?,?,?,?)}";
        try 
        {            
            cs = conexion.prepareCall(sql);          
            cs.setString(1, nombre);
            cs.setString(2, apellido);
            cs.setString(3, identf);
            cs.setString(4, usuario);
            cs.registerOutParameter(5, OracleTypes.CURSOR);
            
            cs.execute();
            rs = (ResultSet) cs.getObject(5);
            System.out.println("entra 3 " + rs);
            
            return rs; 
            
        }catch (Exception e)
            { e.printStackTrace(); }  
        return rs;
    }
    
    /*Autor: Mariela Barrantes
    Descripcion: Verifica que los credenciales de un usuario sean correctos y que exista
    */
    public ResultSet consultaUsuario(String usuario, String clave)  {
        db = getConexion();
        sql = "{call ce.getUsuario(?,?,?)}";
        try 
        {            
            cs = conexion.prepareCall(sql);          
            cs.setString(1, usuario);
            cs.setString(2, clave);
            cs.registerOutParameter(3, OracleTypes.CURSOR);            
            cs.execute();
            rs = (ResultSet) cs.getObject(3);
            System.out.println("conexion " + rs);            
            return rs; 
            
        }catch (Exception e)
            { e.printStackTrace(); }  
        return rs;
    }
}


